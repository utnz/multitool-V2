# Hurrifics -Multitool
Hurrific is a Open-Source Multitool written by myself, contains a lot of things such as a phone spoofer, ip lookup, dox tool etc. In the pswd file, is the password to decrypt the .rar file. Enjoy! :)


It contains:

1. Ip pinger
2. Ip stresser
3. Ip lookup
4. Port Scanner
5. Open putty
6. Dox tool
7. USA fake info generator
8. 30+ phishing sites
9. Extreme doxing tool
10. Rat/Virus creator (github)
11. Keyword generator tool
12. Vpn/Ovh
13. Open cyberhub (Hacking tools and more)
14. Open vedbox (Useful tools)
15. Ascii art
16. Random IP generator
17. Steam account generator
18. Minecraft & Spotify generator
19. Rat tutorial
20. Sick fonts (text etc.)
21. Phone spoofer (ssl)
22. Sms bomber (iOS)
23. Ip-Logger
24. Botting panel (All socials)
25. Instagram ID searcher
26. Fortnite Aimbot/Wallhack
27. EXIT 
